/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package AAACustomerServices.service;

import com.liferay.portal.kernel.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link sitiServicesLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see sitiServicesLocalService
 * @generated
 */
public class sitiServicesLocalServiceWrapper
	implements ServiceWrapper<sitiServicesLocalService>,
			   sitiServicesLocalService {

	public sitiServicesLocalServiceWrapper() {
		this(null);
	}

	public sitiServicesLocalServiceWrapper(
		sitiServicesLocalService sitiServicesLocalService) {

		_sitiServicesLocalService = sitiServicesLocalService;
	}

	@Override
	public AAACustomerServices.model.sitiServices addServices(
			long userId, long groupId, String serviceName, String serviceType,
			String servicePrice,
			com.liferay.portal.kernel.service.ServiceContext serviceContext)
		throws com.liferay.portal.kernel.exception.PortalException,
			   com.liferay.portal.kernel.exception.SystemException {

		return _sitiServicesLocalService.addServices(
			userId, groupId, serviceName, serviceType, servicePrice,
			serviceContext);
	}

	@Override
	public AAACustomerServices.model.sitiServices addServices(
			long userId, long groupId, String serviceName, String servicePrice,
			String serviceExpiration, String serviceType,
			com.liferay.portal.kernel.service.ServiceContext serviceContext)
		throws com.liferay.portal.kernel.exception.PortalException,
			   com.liferay.portal.kernel.exception.SystemException {

		return _sitiServicesLocalService.addServices(
			userId, groupId, serviceName, servicePrice, serviceExpiration,
			serviceType, serviceContext);
	}

	/**
	 * Adds the siti services to the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect sitiServicesLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param sitiServices the siti services
	 * @return the siti services that was added
	 */
	@Override
	public AAACustomerServices.model.sitiServices addsitiServices(
		AAACustomerServices.model.sitiServices sitiServices) {

		return _sitiServicesLocalService.addsitiServices(sitiServices);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel createPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _sitiServicesLocalService.createPersistedModel(primaryKeyObj);
	}

	/**
	 * Creates a new siti services with the primary key. Does not add the siti services to the database.
	 *
	 * @param serviceId the primary key for the new siti services
	 * @return the new siti services
	 */
	@Override
	public AAACustomerServices.model.sitiServices createsitiServices(
		long serviceId) {

		return _sitiServicesLocalService.createsitiServices(serviceId);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel deletePersistedModel(
			com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _sitiServicesLocalService.deletePersistedModel(persistedModel);
	}

	@Override
	public AAACustomerServices.model.sitiServices deleteServices(long serviceId)
		throws com.liferay.portal.kernel.exception.PortalException,
			   com.liferay.portal.kernel.exception.SystemException {

		return _sitiServicesLocalService.deleteServices(serviceId);
	}

	@Override
	public AAACustomerServices.model.sitiServices deleteServices(
			AAACustomerServices.model.sitiServices services)
		throws com.liferay.portal.kernel.exception.SystemException {

		return _sitiServicesLocalService.deleteServices(services);
	}

	/**
	 * Deletes the siti services with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect sitiServicesLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param serviceId the primary key of the siti services
	 * @return the siti services that was removed
	 * @throws PortalException if a siti services with the primary key could not be found
	 */
	@Override
	public AAACustomerServices.model.sitiServices deletesitiServices(
			long serviceId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _sitiServicesLocalService.deletesitiServices(serviceId);
	}

	/**
	 * Deletes the siti services from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect sitiServicesLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param sitiServices the siti services
	 * @return the siti services that was removed
	 */
	@Override
	public AAACustomerServices.model.sitiServices deletesitiServices(
		AAACustomerServices.model.sitiServices sitiServices) {

		return _sitiServicesLocalService.deletesitiServices(sitiServices);
	}

	@Override
	public <T> T dslQuery(com.liferay.petra.sql.dsl.query.DSLQuery dslQuery) {
		return _sitiServicesLocalService.dslQuery(dslQuery);
	}

	@Override
	public int dslQueryCount(
		com.liferay.petra.sql.dsl.query.DSLQuery dslQuery) {

		return _sitiServicesLocalService.dslQueryCount(dslQuery);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _sitiServicesLocalService.dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _sitiServicesLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AAACustomerServices.model.impl.sitiServicesModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {

		return _sitiServicesLocalService.dynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AAACustomerServices.model.impl.sitiServicesModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {

		return _sitiServicesLocalService.dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _sitiServicesLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return _sitiServicesLocalService.dynamicQueryCount(
			dynamicQuery, projection);
	}

	@Override
	public AAACustomerServices.model.sitiServices fetchsitiServices(
		long serviceId) {

		return _sitiServicesLocalService.fetchsitiServices(serviceId);
	}

	/**
	 * Returns the siti services matching the UUID and group.
	 *
	 * @param uuid the siti services's UUID
	 * @param groupId the primary key of the group
	 * @return the matching siti services, or <code>null</code> if a matching siti services could not be found
	 */
	@Override
	public AAACustomerServices.model.sitiServices
		fetchsitiServicesByUuidAndGroupId(String uuid, long groupId) {

		return _sitiServicesLocalService.fetchsitiServicesByUuidAndGroupId(
			uuid, groupId);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery
		getActionableDynamicQuery() {

		return _sitiServicesLocalService.getActionableDynamicQuery();
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.ExportActionableDynamicQuery
		getExportActionableDynamicQuery(
			com.liferay.exportimport.kernel.lar.PortletDataContext
				portletDataContext) {

		return _sitiServicesLocalService.getExportActionableDynamicQuery(
			portletDataContext);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery
		getIndexableActionableDynamicQuery() {

		return _sitiServicesLocalService.getIndexableActionableDynamicQuery();
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	@Override
	public String getOSGiServiceIdentifier() {
		return _sitiServicesLocalService.getOSGiServiceIdentifier();
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel getPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _sitiServicesLocalService.getPersistedModel(primaryKeyObj);
	}

	@Override
	public java.util.List<AAACustomerServices.model.sitiServices>
			getServicesByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {

		return _sitiServicesLocalService.getServicesByGroupId(groupId);
	}

	@Override
	public java.util.List<AAACustomerServices.model.sitiServices>
			getServicesByGroupId(long groupId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {

		return _sitiServicesLocalService.getServicesByGroupId(
			groupId, start, end);
	}

	@Override
	public int getServicesCountByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {

		return _sitiServicesLocalService.getServicesCountByGroupId(groupId);
	}

	/**
	 * Returns the siti services with the primary key.
	 *
	 * @param serviceId the primary key of the siti services
	 * @return the siti services
	 * @throws PortalException if a siti services with the primary key could not be found
	 */
	@Override
	public AAACustomerServices.model.sitiServices getsitiServices(
			long serviceId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _sitiServicesLocalService.getsitiServices(serviceId);
	}

	/**
	 * Returns the siti services matching the UUID and group.
	 *
	 * @param uuid the siti services's UUID
	 * @param groupId the primary key of the group
	 * @return the matching siti services
	 * @throws PortalException if a matching siti services could not be found
	 */
	@Override
	public AAACustomerServices.model.sitiServices
			getsitiServicesByUuidAndGroupId(String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _sitiServicesLocalService.getsitiServicesByUuidAndGroupId(
			uuid, groupId);
	}

	/**
	 * Returns a range of all the siti serviceses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AAACustomerServices.model.impl.sitiServicesModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of siti serviceses
	 * @param end the upper bound of the range of siti serviceses (not inclusive)
	 * @return the range of siti serviceses
	 */
	@Override
	public java.util.List<AAACustomerServices.model.sitiServices>
		getsitiServiceses(int start, int end) {

		return _sitiServicesLocalService.getsitiServiceses(start, end);
	}

	/**
	 * Returns all the siti serviceses matching the UUID and company.
	 *
	 * @param uuid the UUID of the siti serviceses
	 * @param companyId the primary key of the company
	 * @return the matching siti serviceses, or an empty list if no matches were found
	 */
	@Override
	public java.util.List<AAACustomerServices.model.sitiServices>
		getsitiServicesesByUuidAndCompanyId(String uuid, long companyId) {

		return _sitiServicesLocalService.getsitiServicesesByUuidAndCompanyId(
			uuid, companyId);
	}

	/**
	 * Returns a range of siti serviceses matching the UUID and company.
	 *
	 * @param uuid the UUID of the siti serviceses
	 * @param companyId the primary key of the company
	 * @param start the lower bound of the range of siti serviceses
	 * @param end the upper bound of the range of siti serviceses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the range of matching siti serviceses, or an empty list if no matches were found
	 */
	@Override
	public java.util.List<AAACustomerServices.model.sitiServices>
		getsitiServicesesByUuidAndCompanyId(
			String uuid, long companyId, int start, int end,
			com.liferay.portal.kernel.util.OrderByComparator
				<AAACustomerServices.model.sitiServices> orderByComparator) {

		return _sitiServicesLocalService.getsitiServicesesByUuidAndCompanyId(
			uuid, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns the number of siti serviceses.
	 *
	 * @return the number of siti serviceses
	 */
	@Override
	public int getsitiServicesesCount() {
		return _sitiServicesLocalService.getsitiServicesesCount();
	}

	@Override
	public AAACustomerServices.model.sitiServices updateServices(
			long userId, long serviceId, String serviceName, String serviceType,
			String servicePrice,
			com.liferay.portal.kernel.service.ServiceContext serviceContext)
		throws com.liferay.portal.kernel.exception.PortalException,
			   com.liferay.portal.kernel.exception.SystemException {

		return _sitiServicesLocalService.updateServices(
			userId, serviceId, serviceName, serviceType, servicePrice,
			serviceContext);
	}

	@Override
	public AAACustomerServices.model.sitiServices updateServices(
			long userId, long serviceId, String serviceName, String serviceType,
			String servicePrice, String serviceExpiration,
			com.liferay.portal.kernel.service.ServiceContext serviceContext)
		throws com.liferay.portal.kernel.exception.PortalException,
			   com.liferay.portal.kernel.exception.SystemException {

		return _sitiServicesLocalService.updateServices(
			userId, serviceId, serviceName, serviceType, servicePrice,
			serviceExpiration, serviceContext);
	}

	/**
	 * Updates the siti services in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect sitiServicesLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param sitiServices the siti services
	 * @return the siti services that was updated
	 */
	@Override
	public AAACustomerServices.model.sitiServices updatesitiServices(
		AAACustomerServices.model.sitiServices sitiServices) {

		return _sitiServicesLocalService.updatesitiServices(sitiServices);
	}

	@Override
	public sitiServicesLocalService getWrappedService() {
		return _sitiServicesLocalService;
	}

	@Override
	public void setWrappedService(
		sitiServicesLocalService sitiServicesLocalService) {

		_sitiServicesLocalService = sitiServicesLocalService;
	}

	private sitiServicesLocalService _sitiServicesLocalService;

}