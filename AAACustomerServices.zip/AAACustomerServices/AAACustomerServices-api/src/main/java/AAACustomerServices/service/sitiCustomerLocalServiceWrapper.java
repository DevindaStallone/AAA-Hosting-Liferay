/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package AAACustomerServices.service;

import com.liferay.portal.kernel.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link sitiCustomerLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see sitiCustomerLocalService
 * @generated
 */
public class sitiCustomerLocalServiceWrapper
	implements ServiceWrapper<sitiCustomerLocalService>,
			   sitiCustomerLocalService {

	public sitiCustomerLocalServiceWrapper() {
		this(null);
	}

	public sitiCustomerLocalServiceWrapper(
		sitiCustomerLocalService sitiCustomerLocalService) {

		_sitiCustomerLocalService = sitiCustomerLocalService;
	}

	@Override
	public AAACustomerServices.model.sitiCustomer addCustomer(
			long userId, long groupId, String name, String email,
			String address, String national_Id, String contact, int month,
			int day, int year, int hour, int minute, long serviceId,
			com.liferay.portal.kernel.service.ServiceContext serviceContext)
		throws com.liferay.portal.kernel.exception.PortalException,
			   com.liferay.portal.kernel.exception.SystemException {

		return _sitiCustomerLocalService.addCustomer(
			userId, groupId, name, email, address, national_Id, contact, month,
			day, year, hour, minute, serviceId, serviceContext);
	}

	/**
	 * Adds the siti customer to the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect sitiCustomerLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param sitiCustomer the siti customer
	 * @return the siti customer that was added
	 */
	@Override
	public AAACustomerServices.model.sitiCustomer addsitiCustomer(
		AAACustomerServices.model.sitiCustomer sitiCustomer) {

		return _sitiCustomerLocalService.addsitiCustomer(sitiCustomer);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel createPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _sitiCustomerLocalService.createPersistedModel(primaryKeyObj);
	}

	/**
	 * Creates a new siti customer with the primary key. Does not add the siti customer to the database.
	 *
	 * @param customerId the primary key for the new siti customer
	 * @return the new siti customer
	 */
	@Override
	public AAACustomerServices.model.sitiCustomer createsitiCustomer(
		long customerId) {

		return _sitiCustomerLocalService.createsitiCustomer(customerId);
	}

	@Override
	public AAACustomerServices.model.sitiCustomer deleteCustomer(
			long customerId)
		throws com.liferay.portal.kernel.exception.PortalException,
			   com.liferay.portal.kernel.exception.SystemException {

		return _sitiCustomerLocalService.deleteCustomer(customerId);
	}

	@Override
	public AAACustomerServices.model.sitiCustomer deleteCustomer(
			AAACustomerServices.model.sitiCustomer customer)
		throws com.liferay.portal.kernel.exception.SystemException {

		return _sitiCustomerLocalService.deleteCustomer(customer);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel deletePersistedModel(
			com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _sitiCustomerLocalService.deletePersistedModel(persistedModel);
	}

	/**
	 * Deletes the siti customer with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect sitiCustomerLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param customerId the primary key of the siti customer
	 * @return the siti customer that was removed
	 * @throws PortalException if a siti customer with the primary key could not be found
	 */
	@Override
	public AAACustomerServices.model.sitiCustomer deletesitiCustomer(
			long customerId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _sitiCustomerLocalService.deletesitiCustomer(customerId);
	}

	/**
	 * Deletes the siti customer from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect sitiCustomerLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param sitiCustomer the siti customer
	 * @return the siti customer that was removed
	 */
	@Override
	public AAACustomerServices.model.sitiCustomer deletesitiCustomer(
		AAACustomerServices.model.sitiCustomer sitiCustomer) {

		return _sitiCustomerLocalService.deletesitiCustomer(sitiCustomer);
	}

	@Override
	public <T> T dslQuery(com.liferay.petra.sql.dsl.query.DSLQuery dslQuery) {
		return _sitiCustomerLocalService.dslQuery(dslQuery);
	}

	@Override
	public int dslQueryCount(
		com.liferay.petra.sql.dsl.query.DSLQuery dslQuery) {

		return _sitiCustomerLocalService.dslQueryCount(dslQuery);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _sitiCustomerLocalService.dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _sitiCustomerLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AAACustomerServices.model.impl.sitiCustomerModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {

		return _sitiCustomerLocalService.dynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AAACustomerServices.model.impl.sitiCustomerModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {

		return _sitiCustomerLocalService.dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _sitiCustomerLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return _sitiCustomerLocalService.dynamicQueryCount(
			dynamicQuery, projection);
	}

	@Override
	public AAACustomerServices.model.sitiCustomer fetchsitiCustomer(
		long customerId) {

		return _sitiCustomerLocalService.fetchsitiCustomer(customerId);
	}

	/**
	 * Returns the siti customer matching the UUID and group.
	 *
	 * @param uuid the siti customer's UUID
	 * @param groupId the primary key of the group
	 * @return the matching siti customer, or <code>null</code> if a matching siti customer could not be found
	 */
	@Override
	public AAACustomerServices.model.sitiCustomer
		fetchsitiCustomerByUuidAndGroupId(String uuid, long groupId) {

		return _sitiCustomerLocalService.fetchsitiCustomerByUuidAndGroupId(
			uuid, groupId);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery
		getActionableDynamicQuery() {

		return _sitiCustomerLocalService.getActionableDynamicQuery();
	}

	@Override
	public AAACustomerServices.model.sitiCustomer getCustomer(long customerId)
		throws com.liferay.portal.kernel.exception.PortalException,
			   com.liferay.portal.kernel.exception.SystemException {

		return _sitiCustomerLocalService.getCustomer(customerId);
	}

	@Override
	public java.util.List<AAACustomerServices.model.sitiCustomer>
			getCustomersByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {

		return _sitiCustomerLocalService.getCustomersByGroupId(groupId);
	}

	@Override
	public java.util.List<AAACustomerServices.model.sitiCustomer>
			getCustomersByGroupId(long groupId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {

		return _sitiCustomerLocalService.getCustomersByGroupId(
			groupId, start, end);
	}

	@Override
	public int getCustomersCountByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {

		return _sitiCustomerLocalService.getCustomersCountByGroupId(groupId);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.ExportActionableDynamicQuery
		getExportActionableDynamicQuery(
			com.liferay.exportimport.kernel.lar.PortletDataContext
				portletDataContext) {

		return _sitiCustomerLocalService.getExportActionableDynamicQuery(
			portletDataContext);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery
		getIndexableActionableDynamicQuery() {

		return _sitiCustomerLocalService.getIndexableActionableDynamicQuery();
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	@Override
	public String getOSGiServiceIdentifier() {
		return _sitiCustomerLocalService.getOSGiServiceIdentifier();
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel getPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _sitiCustomerLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	 * Returns the siti customer with the primary key.
	 *
	 * @param customerId the primary key of the siti customer
	 * @return the siti customer
	 * @throws PortalException if a siti customer with the primary key could not be found
	 */
	@Override
	public AAACustomerServices.model.sitiCustomer getsitiCustomer(
			long customerId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _sitiCustomerLocalService.getsitiCustomer(customerId);
	}

	/**
	 * Returns the siti customer matching the UUID and group.
	 *
	 * @param uuid the siti customer's UUID
	 * @param groupId the primary key of the group
	 * @return the matching siti customer
	 * @throws PortalException if a matching siti customer could not be found
	 */
	@Override
	public AAACustomerServices.model.sitiCustomer
			getsitiCustomerByUuidAndGroupId(String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _sitiCustomerLocalService.getsitiCustomerByUuidAndGroupId(
			uuid, groupId);
	}

	/**
	 * Returns a range of all the siti customers.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AAACustomerServices.model.impl.sitiCustomerModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of siti customers
	 * @param end the upper bound of the range of siti customers (not inclusive)
	 * @return the range of siti customers
	 */
	@Override
	public java.util.List<AAACustomerServices.model.sitiCustomer>
		getsitiCustomers(int start, int end) {

		return _sitiCustomerLocalService.getsitiCustomers(start, end);
	}

	/**
	 * Returns all the siti customers matching the UUID and company.
	 *
	 * @param uuid the UUID of the siti customers
	 * @param companyId the primary key of the company
	 * @return the matching siti customers, or an empty list if no matches were found
	 */
	@Override
	public java.util.List<AAACustomerServices.model.sitiCustomer>
		getsitiCustomersByUuidAndCompanyId(String uuid, long companyId) {

		return _sitiCustomerLocalService.getsitiCustomersByUuidAndCompanyId(
			uuid, companyId);
	}

	/**
	 * Returns a range of siti customers matching the UUID and company.
	 *
	 * @param uuid the UUID of the siti customers
	 * @param companyId the primary key of the company
	 * @param start the lower bound of the range of siti customers
	 * @param end the upper bound of the range of siti customers (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the range of matching siti customers, or an empty list if no matches were found
	 */
	@Override
	public java.util.List<AAACustomerServices.model.sitiCustomer>
		getsitiCustomersByUuidAndCompanyId(
			String uuid, long companyId, int start, int end,
			com.liferay.portal.kernel.util.OrderByComparator
				<AAACustomerServices.model.sitiCustomer> orderByComparator) {

		return _sitiCustomerLocalService.getsitiCustomersByUuidAndCompanyId(
			uuid, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns the number of siti customers.
	 *
	 * @return the number of siti customers
	 */
	@Override
	public int getsitiCustomersCount() {
		return _sitiCustomerLocalService.getsitiCustomersCount();
	}

	@Override
	public AAACustomerServices.model.sitiCustomer updateCustomer(
			long userId, long customerId, String name, String email,
			String address, String national_Id, String contact, int month,
			int day, int year, int hour, int minute, long serviceId,
			com.liferay.portal.kernel.service.ServiceContext serviceContext)
		throws com.liferay.portal.kernel.exception.PortalException,
			   com.liferay.portal.kernel.exception.SystemException {

		return _sitiCustomerLocalService.updateCustomer(
			userId, customerId, name, email, address, national_Id, contact,
			month, day, year, hour, minute, serviceId, serviceContext);
	}

	/**
	 * Updates the siti customer in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect sitiCustomerLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param sitiCustomer the siti customer
	 * @return the siti customer that was updated
	 */
	@Override
	public AAACustomerServices.model.sitiCustomer updatesitiCustomer(
		AAACustomerServices.model.sitiCustomer sitiCustomer) {

		return _sitiCustomerLocalService.updatesitiCustomer(sitiCustomer);
	}

	@Override
	public sitiCustomerLocalService getWrappedService() {
		return _sitiCustomerLocalService;
	}

	@Override
	public void setWrappedService(
		sitiCustomerLocalService sitiCustomerLocalService) {

		_sitiCustomerLocalService = sitiCustomerLocalService;
	}

	private sitiCustomerLocalService _sitiCustomerLocalService;

}