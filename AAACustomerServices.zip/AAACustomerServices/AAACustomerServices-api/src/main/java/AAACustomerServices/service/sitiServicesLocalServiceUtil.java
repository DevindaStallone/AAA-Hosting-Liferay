/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package AAACustomerServices.service;

import AAACustomerServices.model.sitiServices;

import com.liferay.petra.sql.dsl.query.DSLQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.model.PersistedModel;
import com.liferay.portal.kernel.util.OrderByComparator;

import java.io.Serializable;

import java.util.List;

/**
 * Provides the local service utility for sitiServices. This utility wraps
 * <code>AAACustomerServices.service.impl.sitiServicesLocalServiceImpl</code> and
 * is an access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author Brian Wing Shun Chan
 * @see sitiServicesLocalService
 * @generated
 */
public class sitiServicesLocalServiceUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to <code>AAACustomerServices.service.impl.sitiServicesLocalServiceImpl</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static sitiServices addServices(
			long userId, long groupId, String serviceName, String serviceType,
			String servicePrice,
			com.liferay.portal.kernel.service.ServiceContext serviceContext)
		throws PortalException, SystemException {

		return getService().addServices(
			userId, groupId, serviceName, serviceType, servicePrice,
			serviceContext);
	}

	public static sitiServices addServices(
			long userId, long groupId, String serviceName, String servicePrice,
			String serviceExpiration, String serviceType,
			com.liferay.portal.kernel.service.ServiceContext serviceContext)
		throws PortalException, SystemException {

		return getService().addServices(
			userId, groupId, serviceName, servicePrice, serviceExpiration,
			serviceType, serviceContext);
	}

	/**
	 * Adds the siti services to the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect sitiServicesLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param sitiServices the siti services
	 * @return the siti services that was added
	 */
	public static sitiServices addsitiServices(sitiServices sitiServices) {
		return getService().addsitiServices(sitiServices);
	}

	/**
	 * @throws PortalException
	 */
	public static PersistedModel createPersistedModel(
			Serializable primaryKeyObj)
		throws PortalException {

		return getService().createPersistedModel(primaryKeyObj);
	}

	/**
	 * Creates a new siti services with the primary key. Does not add the siti services to the database.
	 *
	 * @param serviceId the primary key for the new siti services
	 * @return the new siti services
	 */
	public static sitiServices createsitiServices(long serviceId) {
		return getService().createsitiServices(serviceId);
	}

	/**
	 * @throws PortalException
	 */
	public static PersistedModel deletePersistedModel(
			PersistedModel persistedModel)
		throws PortalException {

		return getService().deletePersistedModel(persistedModel);
	}

	public static sitiServices deleteServices(long serviceId)
		throws PortalException, SystemException {

		return getService().deleteServices(serviceId);
	}

	public static sitiServices deleteServices(sitiServices services)
		throws SystemException {

		return getService().deleteServices(services);
	}

	/**
	 * Deletes the siti services with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect sitiServicesLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param serviceId the primary key of the siti services
	 * @return the siti services that was removed
	 * @throws PortalException if a siti services with the primary key could not be found
	 */
	public static sitiServices deletesitiServices(long serviceId)
		throws PortalException {

		return getService().deletesitiServices(serviceId);
	}

	/**
	 * Deletes the siti services from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect sitiServicesLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param sitiServices the siti services
	 * @return the siti services that was removed
	 */
	public static sitiServices deletesitiServices(sitiServices sitiServices) {
		return getService().deletesitiServices(sitiServices);
	}

	public static <T> T dslQuery(DSLQuery dslQuery) {
		return getService().dslQuery(dslQuery);
	}

	public static int dslQueryCount(DSLQuery dslQuery) {
		return getService().dslQueryCount(dslQuery);
	}

	public static DynamicQuery dynamicQuery() {
		return getService().dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	public static <T> List<T> dynamicQuery(DynamicQuery dynamicQuery) {
		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AAACustomerServices.model.impl.sitiServicesModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	public static <T> List<T> dynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {

		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AAACustomerServices.model.impl.sitiServicesModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	public static <T> List<T> dynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<T> orderByComparator) {

		return getService().dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	public static long dynamicQueryCount(DynamicQuery dynamicQuery) {
		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	public static long dynamicQueryCount(
		DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static sitiServices fetchsitiServices(long serviceId) {
		return getService().fetchsitiServices(serviceId);
	}

	/**
	 * Returns the siti services matching the UUID and group.
	 *
	 * @param uuid the siti services's UUID
	 * @param groupId the primary key of the group
	 * @return the matching siti services, or <code>null</code> if a matching siti services could not be found
	 */
	public static sitiServices fetchsitiServicesByUuidAndGroupId(
		String uuid, long groupId) {

		return getService().fetchsitiServicesByUuidAndGroupId(uuid, groupId);
	}

	public static com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery
		getActionableDynamicQuery() {

		return getService().getActionableDynamicQuery();
	}

	public static com.liferay.portal.kernel.dao.orm.ExportActionableDynamicQuery
		getExportActionableDynamicQuery(
			com.liferay.exportimport.kernel.lar.PortletDataContext
				portletDataContext) {

		return getService().getExportActionableDynamicQuery(portletDataContext);
	}

	public static
		com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery
			getIndexableActionableDynamicQuery() {

		return getService().getIndexableActionableDynamicQuery();
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	public static String getOSGiServiceIdentifier() {
		return getService().getOSGiServiceIdentifier();
	}

	/**
	 * @throws PortalException
	 */
	public static PersistedModel getPersistedModel(Serializable primaryKeyObj)
		throws PortalException {

		return getService().getPersistedModel(primaryKeyObj);
	}

	public static List<sitiServices> getServicesByGroupId(long groupId)
		throws SystemException {

		return getService().getServicesByGroupId(groupId);
	}

	public static List<sitiServices> getServicesByGroupId(
			long groupId, int start, int end)
		throws SystemException {

		return getService().getServicesByGroupId(groupId, start, end);
	}

	public static int getServicesCountByGroupId(long groupId)
		throws SystemException {

		return getService().getServicesCountByGroupId(groupId);
	}

	/**
	 * Returns the siti services with the primary key.
	 *
	 * @param serviceId the primary key of the siti services
	 * @return the siti services
	 * @throws PortalException if a siti services with the primary key could not be found
	 */
	public static sitiServices getsitiServices(long serviceId)
		throws PortalException {

		return getService().getsitiServices(serviceId);
	}

	/**
	 * Returns the siti services matching the UUID and group.
	 *
	 * @param uuid the siti services's UUID
	 * @param groupId the primary key of the group
	 * @return the matching siti services
	 * @throws PortalException if a matching siti services could not be found
	 */
	public static sitiServices getsitiServicesByUuidAndGroupId(
			String uuid, long groupId)
		throws PortalException {

		return getService().getsitiServicesByUuidAndGroupId(uuid, groupId);
	}

	/**
	 * Returns a range of all the siti serviceses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AAACustomerServices.model.impl.sitiServicesModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of siti serviceses
	 * @param end the upper bound of the range of siti serviceses (not inclusive)
	 * @return the range of siti serviceses
	 */
	public static List<sitiServices> getsitiServiceses(int start, int end) {
		return getService().getsitiServiceses(start, end);
	}

	/**
	 * Returns all the siti serviceses matching the UUID and company.
	 *
	 * @param uuid the UUID of the siti serviceses
	 * @param companyId the primary key of the company
	 * @return the matching siti serviceses, or an empty list if no matches were found
	 */
	public static List<sitiServices> getsitiServicesesByUuidAndCompanyId(
		String uuid, long companyId) {

		return getService().getsitiServicesesByUuidAndCompanyId(
			uuid, companyId);
	}

	/**
	 * Returns a range of siti serviceses matching the UUID and company.
	 *
	 * @param uuid the UUID of the siti serviceses
	 * @param companyId the primary key of the company
	 * @param start the lower bound of the range of siti serviceses
	 * @param end the upper bound of the range of siti serviceses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the range of matching siti serviceses, or an empty list if no matches were found
	 */
	public static List<sitiServices> getsitiServicesesByUuidAndCompanyId(
		String uuid, long companyId, int start, int end,
		OrderByComparator<sitiServices> orderByComparator) {

		return getService().getsitiServicesesByUuidAndCompanyId(
			uuid, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns the number of siti serviceses.
	 *
	 * @return the number of siti serviceses
	 */
	public static int getsitiServicesesCount() {
		return getService().getsitiServicesesCount();
	}

	public static sitiServices updateServices(
			long userId, long serviceId, String serviceName, String serviceType,
			String servicePrice,
			com.liferay.portal.kernel.service.ServiceContext serviceContext)
		throws PortalException, SystemException {

		return getService().updateServices(
			userId, serviceId, serviceName, serviceType, servicePrice,
			serviceContext);
	}

	public static sitiServices updateServices(
			long userId, long serviceId, String serviceName, String serviceType,
			String servicePrice, String serviceExpiration,
			com.liferay.portal.kernel.service.ServiceContext serviceContext)
		throws PortalException, SystemException {

		return getService().updateServices(
			userId, serviceId, serviceName, serviceType, servicePrice,
			serviceExpiration, serviceContext);
	}

	/**
	 * Updates the siti services in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect sitiServicesLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param sitiServices the siti services
	 * @return the siti services that was updated
	 */
	public static sitiServices updatesitiServices(sitiServices sitiServices) {
		return getService().updatesitiServices(sitiServices);
	}

	public static sitiServicesLocalService getService() {
		return _service;
	}

	private static volatile sitiServicesLocalService _service;

}