/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package AAACustomerServices.service.impl;

import AAACustomerServices.exception.ServiceNameException;
import AAACustomerServices.model.sitiServices;
import AAACustomerServices.service.base.sitiServicesLocalServiceBaseImpl;

import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.Validator;

import java.util.Date;
import java.util.List;

import org.osgi.service.component.annotations.Component;

/**
 * @author Brian Wing Shun Chan
 */
@Component(
	property = "model.class.name=AAACustomerServices.model.sitiServices",
	service = AopService.class
)
public class sitiServicesLocalServiceImpl
	extends sitiServicesLocalServiceBaseImpl {
	
	protected void validate (String serviceName) 
	        throws PortalException {
	    if (Validator.isNull(serviceName)) {
	        throw new ServiceNameException();
	    }

	}
	
	public sitiServices addServices(
	        long userId, long groupId, String serviceName, String servicePrice,
	         String serviceExpiration, String serviceType, ServiceContext serviceContext)
	throws PortalException, SystemException {

		User user = userLocalService.getUserById(userId);

	    Date now = new Date();
	    
	    validate(serviceName);

	    long serviceId =
	        counterLocalService.increment(sitiServices.class.getName());

	    sitiServices services = sitiServicesPersistence.create(serviceId);
	    System.out.println(servicePrice);
	    System.out.println(serviceType);
	    
	    services.setServiceName(serviceName);
	    services.setServiceType(serviceType);
	    services.setServicePrice(servicePrice);
	    services.setServiceExpiration(serviceExpiration);

	    services.setGroupId(groupId);
	    services.setCompanyId(user.getCompanyId());
	    services.setUserId(user.getUserId());
	    services.setCreateDate(serviceContext.getCreateDate(now));
	    services.setModifiedDate(serviceContext.getModifiedDate(now));

	    super.addsitiServices(services);
	    return services;
	}

	public sitiServices deleteServices(sitiServices services)
	    throws SystemException {

	    return sitiServicesPersistence.remove(services);
	}

	public sitiServices deleteServices(long serviceId)
	    throws PortalException, SystemException {

		sitiServices services = sitiServicesPersistence.fetchByPrimaryKey(serviceId);

	    return deleteServices(services);
	}

	public List<sitiServices> getServicesByGroupId(long groupId)
	    throws SystemException {

	    return sitiServicesPersistence.findByGroupId(groupId);
	}

	public List<sitiServices> getServicesByGroupId(
	        long groupId, int start, int end)
	    throws SystemException {

	    return sitiServicesPersistence.findByGroupId(groupId, start, end);
	}

	public int getServicesCountByGroupId(long groupId) throws SystemException {

	    return sitiServicesPersistence.countByGroupId(groupId);
	}

	public sitiServices updateServices(
	        long userId, long serviceId, String serviceName, 
	         String servicePrice, String serviceExpiration, String serviceType, ServiceContext serviceContext)
	    throws PortalException, SystemException {

		User user = userLocalService.getUserById(userId);

	    Date now = new Date();
	    
	    validate(serviceName);

	    sitiServices services = sitiServicesPersistence.findByPrimaryKey(serviceId);

	    services.setServiceName(serviceName);
	    services.setServiceType(serviceType);
	    services.setServicePrice(servicePrice);
	    services.setServiceExpiration(serviceExpiration);

	    services.setModifiedDate(serviceContext.getModifiedDate(now));

	    
	    super.updatesitiServices(services);
	    return services;
	}

	@Override
	public sitiServices addServices(long userId, long groupId, String serviceName, String serviceType,
			String servicePrice, ServiceContext serviceContext) throws PortalException, SystemException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public sitiServices updateServices(long userId, long serviceId, String serviceName, String serviceType,
			String servicePrice, ServiceContext serviceContext) throws PortalException, SystemException {
		// TODO Auto-generated method stub
		return null;
	}

	



}