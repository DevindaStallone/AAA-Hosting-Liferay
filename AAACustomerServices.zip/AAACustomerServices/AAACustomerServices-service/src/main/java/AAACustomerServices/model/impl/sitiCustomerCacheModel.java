/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package AAACustomerServices.model.impl;

import AAACustomerServices.model.sitiCustomer;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing sitiCustomer in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class sitiCustomerCacheModel
	implements CacheModel<sitiCustomer>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof sitiCustomerCacheModel)) {
			return false;
		}

		sitiCustomerCacheModel sitiCustomerCacheModel =
			(sitiCustomerCacheModel)object;

		if (customerId == sitiCustomerCacheModel.customerId) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, customerId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(31);

		sb.append("{uuid=");
		sb.append(uuid);
		sb.append(", customerId=");
		sb.append(customerId);
		sb.append(", customerName=");
		sb.append(customerName);
		sb.append(", customerEmail=");
		sb.append(customerEmail);
		sb.append(", customerAddress=");
		sb.append(customerAddress);
		sb.append(", customerContact=");
		sb.append(customerContact);
		sb.append(", customerNRIC=");
		sb.append(customerNRIC);
		sb.append(", start_date=");
		sb.append(start_date);
		sb.append(", groupId=");
		sb.append(groupId);
		sb.append(", companyId=");
		sb.append(companyId);
		sb.append(", userId=");
		sb.append(userId);
		sb.append(", userName=");
		sb.append(userName);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append(", modifiedDate=");
		sb.append(modifiedDate);
		sb.append(", serviceId=");
		sb.append(serviceId);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public sitiCustomer toEntityModel() {
		sitiCustomerImpl sitiCustomerImpl = new sitiCustomerImpl();

		if (uuid == null) {
			sitiCustomerImpl.setUuid("");
		}
		else {
			sitiCustomerImpl.setUuid(uuid);
		}

		sitiCustomerImpl.setCustomerId(customerId);

		if (customerName == null) {
			sitiCustomerImpl.setCustomerName("");
		}
		else {
			sitiCustomerImpl.setCustomerName(customerName);
		}

		if (customerEmail == null) {
			sitiCustomerImpl.setCustomerEmail("");
		}
		else {
			sitiCustomerImpl.setCustomerEmail(customerEmail);
		}

		if (customerAddress == null) {
			sitiCustomerImpl.setCustomerAddress("");
		}
		else {
			sitiCustomerImpl.setCustomerAddress(customerAddress);
		}

		if (customerContact == null) {
			sitiCustomerImpl.setCustomerContact("");
		}
		else {
			sitiCustomerImpl.setCustomerContact(customerContact);
		}

		if (customerNRIC == null) {
			sitiCustomerImpl.setCustomerNRIC("");
		}
		else {
			sitiCustomerImpl.setCustomerNRIC(customerNRIC);
		}

		if (start_date == Long.MIN_VALUE) {
			sitiCustomerImpl.setStart_date(null);
		}
		else {
			sitiCustomerImpl.setStart_date(new Date(start_date));
		}

		sitiCustomerImpl.setGroupId(groupId);
		sitiCustomerImpl.setCompanyId(companyId);
		sitiCustomerImpl.setUserId(userId);

		if (userName == null) {
			sitiCustomerImpl.setUserName("");
		}
		else {
			sitiCustomerImpl.setUserName(userName);
		}

		if (createDate == Long.MIN_VALUE) {
			sitiCustomerImpl.setCreateDate(null);
		}
		else {
			sitiCustomerImpl.setCreateDate(new Date(createDate));
		}

		if (modifiedDate == Long.MIN_VALUE) {
			sitiCustomerImpl.setModifiedDate(null);
		}
		else {
			sitiCustomerImpl.setModifiedDate(new Date(modifiedDate));
		}

		sitiCustomerImpl.setServiceId(serviceId);

		sitiCustomerImpl.resetOriginalValues();

		return sitiCustomerImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		uuid = objectInput.readUTF();

		customerId = objectInput.readLong();
		customerName = objectInput.readUTF();
		customerEmail = objectInput.readUTF();
		customerAddress = objectInput.readUTF();
		customerContact = objectInput.readUTF();
		customerNRIC = objectInput.readUTF();
		start_date = objectInput.readLong();

		groupId = objectInput.readLong();

		companyId = objectInput.readLong();

		userId = objectInput.readLong();
		userName = objectInput.readUTF();
		createDate = objectInput.readLong();
		modifiedDate = objectInput.readLong();

		serviceId = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		if (uuid == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(uuid);
		}

		objectOutput.writeLong(customerId);

		if (customerName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(customerName);
		}

		if (customerEmail == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(customerEmail);
		}

		if (customerAddress == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(customerAddress);
		}

		if (customerContact == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(customerContact);
		}

		if (customerNRIC == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(customerNRIC);
		}

		objectOutput.writeLong(start_date);

		objectOutput.writeLong(groupId);

		objectOutput.writeLong(companyId);

		objectOutput.writeLong(userId);

		if (userName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(userName);
		}

		objectOutput.writeLong(createDate);
		objectOutput.writeLong(modifiedDate);

		objectOutput.writeLong(serviceId);
	}

	public String uuid;
	public long customerId;
	public String customerName;
	public String customerEmail;
	public String customerAddress;
	public String customerContact;
	public String customerNRIC;
	public long start_date;
	public long groupId;
	public long companyId;
	public long userId;
	public String userName;
	public long createDate;
	public long modifiedDate;
	public long serviceId;

}