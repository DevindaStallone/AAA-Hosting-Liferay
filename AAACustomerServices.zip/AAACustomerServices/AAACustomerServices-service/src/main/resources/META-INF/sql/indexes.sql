create index IX_871D1D9D on AAA_sitiCustomer (groupId);
create index IX_69B63A61 on AAA_sitiCustomer (uuid_[$COLUMN_LENGTH:75$], companyId);
create unique index IX_DA9BE523 on AAA_sitiCustomer (uuid_[$COLUMN_LENGTH:75$], groupId);

create index IX_A5023D1D on AAA_sitiServices (groupId);
create index IX_26DC8AE1 on AAA_sitiServices (uuid_[$COLUMN_LENGTH:75$], companyId);
create unique index IX_761C55A3 on AAA_sitiServices (uuid_[$COLUMN_LENGTH:75$], groupId);